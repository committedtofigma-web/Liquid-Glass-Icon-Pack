package com.liquidglass.iconpack;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#D5CFC3"));
        root.setPadding(64, 64, 64, 64);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(260, 260);
        lp.bottomMargin = 40;
        root.addView(icon, lp);

        TextView title = new TextView(this);
        title.setText("Liquid Glass Icon Pack");
        title.setTextSize(24f);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.parseColor("#1C1917"));
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView guide = new TextView(this);
        guide.setText(
            "\nInstalled and ready!\n\n" +
            "To apply to ALL apps at once on Samsung:\n" +
            "1. Open Good Lock > Theme Park\n" +
            "2. Tap Icon > Create New > Iconpack\n" +
            "3. Select 'Liquid Glass Icon Pack'\n" +
            "4. Tap Save and Apply!"
        );
        guide.setTextSize(15f);
        guide.setTextColor(Color.parseColor("#44403C"));
        guide.setGravity(Gravity.CENTER);
        root.addView(guide);

        setContentView(root);
    }
}
