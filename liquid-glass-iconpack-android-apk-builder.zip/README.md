# Liquid Glass Icon Pack (Auto-Build Android APK)

This project builds a ready-to-install Android `.apk` icon pack using **GitHub Actions** (no PC or Android Studio required).

It includes:
- **18 custom Liquid Glass icons** mapped to popular Samsung One UI & Android apps (Camera, Calculator, Clock/Timer, Settings, Voice Recorder, Smart View/Cast).
- **Automatic Liquid Glass Icon Masking** (`iconback_glass` + `iconmask_circle` + `iconupon_gloss`) so **every other app on your phone** is automatically wrapped in a glossy liquid-glass bubble.

## How to Build Your `.apk` in 2 Minutes (From Your Phone or PC)
1. Go to [github.com/new](https://github.com/new) and create a new repository (e.g. `liquid-glass-iconpack`).
2. Unzip this folder and upload all files (make sure the `.github` folder is included!)—or push them via Git.
3. Open the **Actions** tab in your GitHub repository.
4. Click **Build Liquid Glass Icon Pack APK** → **Run workflow** (it also runs automatically on push).
5. Once the green checkmark appears (~2 minutes), scroll to **Artifacts** and download **LiquidGlassIconPack-APK**.
6. Unzip it on your Android phone and tap `app-debug.apk` to install.

## How to Apply in 1 Tap on Samsung
1. Open **Good Lock → Theme Park**.
2. Tap **Icon → Create New → Iconpack**.
3. Pick **Liquid Glass Icon Pack**, tap **Save**, and hit **Apply**!
